import { NgModule } from "@angular/core";
import { Route, RouterModule } from '@angular/router';
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { AppComponent } from "./app.component";
import { StudentsModule } from './modules/students/students.module';
import { HomeComponent } from './modules/home/home/home.component';
import { StudentListComponent } from './modules/students/student-list/student-list.component';
import { PageNotFountComponent } from './page-not-fount/page-not-fount.component';
import { StudentDetailsComponent } from "./modules/students/student-details/student-details.component";



const APP_ROUTES: Route[] = [
    { path: "", pathMatch: "full", redirectTo: "home"},
    { path: "home", component: HomeComponent },
    { path: "students", component: StudentListComponent},
    {path: "details", component: StudentDetailsComponent},
    { path: "**", component: PageNotFountComponent }
];
@NgModule({
    declarations: [AppComponent, HomeComponent, PageNotFountComponent],
    imports: [BrowserModule,StudentsModule,RouterModule.forRoot(APP_ROUTES), FormsModule, ReactiveFormsModule, HttpClientModule],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule {
}