import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Student } from "./student.model"
import { Subject, SUBJECT } from './subject.model';
import { Year } from './year.enum';

@Injectable()
export class StudentService {

    constructor(private _http: HttpClient){
        _http.get<Student[]>("/api/values").subscribe(data => {
            this._students = data;
        })
    }

    
    private _selectStudent: Student = null;

    private _selectStudent$: BehaviorSubject<Student> = new BehaviorSubject(this._selectStudent);

    selectStudent$: Observable<Student> = this._selectStudent$.asObservable();

    private _students: Student[];

    saveStudentOnService(studentToSave: Student){
        if(this._students.find(s=>s.id == studentToSave.id )){
            throw new Error('this id not valid');
        }
        this._http.post("/api/values", studentToSave).subscribe(data => {
            console.log(data);
        });
    }

    updateStudentOnService(studentToUpdate: Student){
        this._http.put("/api/values/"+studentToUpdate.id, studentToUpdate).subscribe(data => {
            console.log(data);
        });
    }

    deleteStudentFromService(studentToDelete: Student){
        if(!this._students.find(s=>s.id == studentToDelete.id )){
            throw new Error('this id not valid');
        }
        this._http.delete("/api/values/" + studentToDelete.id).subscribe(data => {
            console.log(data);
        });
    }

    getAllStudent(): Student[]{
        return this._students;
    }

    getAllStudentsFromService(): Observable<Student[]>{
        return this._http.get<Student[]>("api/values");
    }

    getStudentByActive(active: boolean): Observable<Student[]>{
        return this._http.get<Student[]>("api/values/?active="+active);
    }

    getSelectedStudent(){
        return this._selectStudent;
    }

    changeSelectStudent(student: Student){
        this._selectStudent$.next(student);
    }
}