export class Test{
    SubjectName: String;
    Date: string;

    constructor(SubjectName:string, Date: string){
        this.SubjectName = SubjectName;
        this.Date = Date;
    }
}