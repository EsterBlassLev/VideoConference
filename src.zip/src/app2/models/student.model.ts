import { Subject } from './subject.model';
import { Test } from './test.model';
import { Year } from './year.enum';

export class Student{
    id: number;
    firstName: string;
    lastName: string;
    address: string;
    phone: string;
    active: boolean;
    dateLeve: string;
    avgMarks: number;
    subject: Subject;
    year: Year;
    tests: Test[];
    mail: string;

    constructor(){
        this.id = 0;
        this.firstName ="";
        this.lastName = "";
        this.address = "";
        this.phone = "";
        this.active = false;
        this.dateLeve = null;
        this.avgMarks = 0;
        this.subject = null;
        this.year = Year.A;
        this.tests = null; 
    }
}