export enum DetailsType {
    Edit = "edit",
    Add = "add",
    Show = "show"
  }