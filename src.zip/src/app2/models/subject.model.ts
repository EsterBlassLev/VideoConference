export class Subject{
    Name: string;
    Id: number;

    constructor(Name:string, Id: number){
        this.Name = Name;
        this.Id = Id;
    }
}

export const SUBJECT: Subject[] = [
    { Name: "Math", Id: 1 },
    { Name: "English", Id: 2 },
    { Name: "History", Id: 3 },
    { Name: "Nation", Id: 4 }
]