export enum Year{
    'A' = 1,
    'B' = 2,
    'C' = 3
}