import { Component, Input } from "@angular/core";
import { Student } from './models/student.model';
import { Test } from './models/test.model';


@Component({
    selector: "my-app-root",
    templateUrl: "./app.component.html"
})
export class AppComponent {

    testsOfStudent: Test = null;

    printTest(tests: Test){
        this.testsOfStudent = tests;
    }

}