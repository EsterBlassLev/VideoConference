import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SendMailComponent } from './send-mail/send-mail.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { StudentListComponent } from './student-list/student-list.component';
import { TestListComponent } from './test-list/test-list.component';
import { Route, RouterModule } from '@angular/router';
import { StudentService } from 'src/app1/models/students.service';

@NgModule({
    declarations: [StudentListComponent, StudentDetailsComponent, SendMailComponent,TestListComponent],
    imports: [CommonModule, ReactiveFormsModule,FormsModule, HttpClientModule, RouterModule],
    providers: [StudentService],
    exports: [StudentListComponent, StudentDetailsComponent]
})
export class StudentsModule {

}