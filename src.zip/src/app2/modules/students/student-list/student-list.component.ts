import { Component, OnInit } from '@angular/core';
import { from, Observable, Subject } from 'rxjs';
import { DetailsType } from '../../../models/details-type.enum';
import { Student } from '../../../models/student.model';
import { StudentService } from '../../../models/students.service';

import { debounceTime, distinctUntilChanged, filter, map, take, takeUntil, takeWhile } from "rxjs/operators";
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.scss']
})
export class StudentListComponent implements OnInit {

  constructor(private _studentService: StudentService, private _acr: ActivatedRoute) { 

    this._studentService.getAllStudentsFromService().subscribe(data => {
      this.students = data;
      this.printInLogAllStudent1 = from(this.students);
      this.printInLogAllStudent2 = from(this.students).pipe(map((student)=>{return student.firstName + ' - ' + student.lastName}));
      
      this.printInLogAllStudent1.subscribe( student => {
        console.log(student.firstName + ' ' + student.lastName);
      });
  
      this.printInLogAllStudent2.subscribe( student => {
        console.log(student);
      });

    });
    this._studentService.selectStudent$.subscribe(newStudent => {
      this.stSelect = newStudent;
    });

    this.searchObs$.pipe(debounceTime(500), distinctUntilChanged()).subscribe(val => {
      if(val === ""){
        this.students = this._studentService.getAllStudent();
      }
      else{
        this.students = this._studentService.getAllStudent();
        this.students = this.students.filter(s => s.firstName.includes(val));
      }
      console.log(val);
    });

  }

  printInLogAllStudent1: Observable<Student>;

  printInLogAllStudent2: Observable<string>;

  stSelect: Student = null;

  students: Student[];

  selectedStudent: Student = null;

  flag: boolean = false;

  detailsType: DetailsType;

  private _checked: boolean = false;

  chooseSelectStudent(student: Student){
    this._studentService.changeSelectStudent(student);
  }
  
  editStudent(studentToEdit: Student){
    this.detailsType = DetailsType.Edit;
    this.selectedStudent = studentToEdit;
  }

  addNewStudent(){
    this.detailsType = DetailsType.Add;
    this.selectedStudent = new Student();
  }

  addStudentToList(studentToSave: Student){
    if(this.detailsType === DetailsType.Add){
      try{
        this._studentService.saveStudentOnService(studentToSave);
        this.students.push(studentToSave);
      }
      catch{
        console.log("student dont valid", studentToSave);
      }
    }
    else{
      try{
        this._studentService.updateStudentOnService(studentToSave);
        this.students.splice(this.students.findIndex(s=>s.id = studentToSave.id),1);
        this.students.push(studentToSave);
      }
      catch{
        console.log("student dont valid", studentToSave);
      }
    }
  }

  filterStudentsByActive(){
    this._checked = !this._checked;
    if(this._checked){
      this._studentService.getStudentByActive(this._checked).subscribe(data =>{
        this.students = data;
      });
    }
    else{
      this._studentService.getAllStudentsFromService().subscribe(data => {
        this.students = data;
      });
    }
  }

  deletStudentFromList(studentToDelete: Student){
    try{
      this._studentService.deleteStudentFromService(studentToDelete);
      this.students.splice(this.students.indexOf(studentToDelete),1);
    }
    catch{
      console.log("student dont valid", studentToDelete);
    }
  }

  searchObs$: Subject<string> = new Subject();

  search(text: string){
    this.searchObs$.next(text);
  }

  ngOnInit(): void {
  }

}
