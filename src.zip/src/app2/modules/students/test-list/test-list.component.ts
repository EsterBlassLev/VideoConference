import { Component, OnInit } from '@angular/core';
import { Student } from '../../../models/student.model';
import { StudentService } from '../../../models/students.service';

@Component({
  selector: 'app-test-list',
  templateUrl: './test-list.component.html',
  styleUrls: ['./test-list.component.scss']
})
export class TestListComponent implements OnInit {

  constructor(private _studentService: StudentService) {
    this._studentService.selectStudent$.subscribe(newStudent => {
      this.selectedStudent = newStudent;
    })
  }

  selectedStudent: Student = null;

  ngOnInit(): void {
  }

}
