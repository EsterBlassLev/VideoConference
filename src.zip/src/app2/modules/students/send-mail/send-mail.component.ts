import { Component, Input, OnInit } from '@angular/core';
import { BehaviorSubject, from, observable, Observable, Subject } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Student } from '../../../models/student.model';

@Component({
  selector: 'app-send-mail',
  templateUrl: './send-mail.component.html',
  styleUrls: ['./send-mail.component.scss']
})
export class SendMailComponent implements OnInit {

  constructor() {
    this.obsSend1.subscribe(std => {
      this.sendList.push(std);
    });
  }

  ngOnInit(): void {
  }

  @Input()
  students: Student[];

  sendList: string[] = [];

  finishSend: boolean = false;

  obsSend1: Subject<string> = new Subject();

  //obsSend2: Observable<string>;

  sendMail1(){
    this.students.forEach(student => {
      if(student.active){
        try{
          //To-Do: sendMail to student.mail
          this.obsSend1.next(student.firstName + ' mail:' + student.lastName + ' ' + student.mail + ' send mail success!!');
        }
        catch{
          this.obsSend1.next(student.firstName + ' ' + student.lastName + ' ' + student.mail + ' dont send mail!!');
        }
      }
    });
    this.finishSend = true;
  }

  closeSendList(){
    this.sendList = [];
    this.finishSend = false;
  }

}
