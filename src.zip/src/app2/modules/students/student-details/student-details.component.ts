import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from 'src/app1/models/students.service';
import { DetailsType } from '../../../models/details-type.enum';
import { Student } from '../../../models/student.model'
import { Subject, SUBJECT } from '../../../models/subject.model';
import { Year } from '../../../models/year.enum';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.scss']
})
export class StudentDetailsComponent implements OnInit {

  private _student: Student;

  get student(): Student {
    return this._student;
  }

  // @Input()
  set student(val: Student) {
    this._student = val;
    if (val) {
      this.studentForm.controls["id"].setValue(val.id);
      this.studentForm.controls["firstName"].setValue(val.firstName);
      this.studentForm.controls["lastName"].setValue(val.lastName);
      this.studentForm.controls["address"].setValue(val.address);
      this.studentForm.controls["phone"].setValue(val.phone);
      this.studentForm.controls["active"].setValue(val.active);
      this.studentForm.controls["dateLeve"].setValue(val.dateLeve);
      this.studentForm.controls["avgMarks"].setValue(val.avgMarks);
      this.studentForm.controls["subject"].setValue(val.subject);
      this.studentForm.controls["year"].setValue(val.year);
      this.studentForm.controls["mail"].setValue(val.mail);
    }
    this._Studentservice.changeSelectStudent(this.student);
  }

  studentForm: FormGroup = new FormGroup({
    "id": new FormControl("", Validators.required),
    "firstName": new FormControl("", [Validators.required, Validators.minLength(2)]),
    "lastName": new FormControl("", [Validators.required, Validators.minLength(2)]),
    "address": new FormControl("", Validators.required),
    "phone": new FormControl("", [Validators.required,Validators.minLength(9)]),
    "active": new FormControl("",Validators.required),
    "dateLeve": new FormControl(),
    "avgMarks": new FormControl("", Validators.required),
    "subject": new FormControl("",Validators.required),
    "year": new FormControl("",Validators.required),
    "mail": new FormControl("",Validators.required)
  })

  @Input()
  detailsType: DetailsType = DetailsType.Show;

  detailsTypes = DetailsType;

  Year = Year;

  subjectList: Subject[] = SUBJECT;

  @Output()
  onSaveStudent: EventEmitter<Student> = new EventEmitter();

  submitted: boolean = false;
  
  saveStudent() {
    if (this.studentForm.valid) {
      this.submitted = true;
      this.student = this.studentForm.value;
      this.onSaveStudent.emit(this.student);
    }
  }

  constructor(private _Studentservice: StudentService, private _acr: ActivatedRoute) { }
  studentNew:string = null;
  studentId: number = 0;

   ngOnInit(): void {
    this._Studentservice.getAllStudentsFromService().subscribe(data => {
      if (this.studentId > 0)
        this.student = data.find(x=>x.id === this.studentId);
      else if(this.studentNew!=null)
        this.student = new Student;
    });
    
    this._acr.paramMap.subscribe(param => {
      if (param.get("id") === "add")
        this.studentNew = param.get("id");
      else
      this.studentId = +param.get("id");
    })
  }
}