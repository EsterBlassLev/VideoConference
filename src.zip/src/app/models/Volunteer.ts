export class Volunteer{
    id: number;
    firstName: string;
    lastName: string;
    days:boolean[];

    constructor(){
        this.id = 0;
        this.firstName ="";
        this.lastName = "";
        this.days=null;
    }
}