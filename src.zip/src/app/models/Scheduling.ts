import { Volunteer } from "./Volunteer";

export class SchedulingType{
    CanBe:Volunteer[];
    Choise:Volunteer;
}

export class Scheduling{
    arr:SchedulingType[];
}