import { Component, Input } from "@angular/core";



@Component({
    selector: "my-app-root",
    templateUrl: "./app.component.html"
})
export class AppComponent {


}