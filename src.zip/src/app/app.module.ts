import { NgModule } from "@angular/core";
import { Route, RouterModule } from '@angular/router';
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { AppComponent } from "./app.component";
import { PageNotFountComponent } from "./page-not-fount/page-not-fount.component";
import { VolunteerListComponentComponent } from "./moduls/volunteer-module/volunteer-list-component/volunteer-list-component.component";
import { VolunteerDetailsComponent } from "./moduls/volunteer-module/volunteer-details/volunteer-details.component";
import { VolunteerModuleModule } from "./moduls/volunteer-module/volunteer-module.module";
import { SchedulingListComponent } from "./moduls/scheduling-module/scheduling-list/scheduling-list.component";
import { SchedulingDetailsComponent } from "./moduls/scheduling-module/scheduling-details/scheduling-details.component";
import { SchedulingModule } from "./moduls/scheduling-module/scheduling-module.module";



const APP_ROUTES: Route[] = [
    { path: "", pathMatch: "full", redirectTo: "home"},
    { path: "volunteer", component: VolunteerListComponentComponent },
    { path: "scheduling", component: SchedulingListComponent},
   // {path: "details", component: VolunteerDetailsComponent},
    { path: "**", component: PageNotFountComponent }
];
@NgModule({
    declarations: [AppComponent, PageNotFountComponent],
    imports: [BrowserModule,VolunteerModuleModule, SchedulingModule,RouterModule.forRoot(APP_ROUTES), FormsModule, ReactiveFormsModule, HttpClientModule],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule {
    
}