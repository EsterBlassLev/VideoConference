import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Scheduling } from "src/app/models/Scheduling";
import { Volunteer } from "src/app/models/Volunteer";

@Injectable()
export class SchedulingService {

    constructor(private _http: HttpClient) { }

    getAllScheduling(): Observable<Scheduling> {
        return this._http.get<Scheduling>("api/Scheduling");
    }
    UpdateSchedulingByDay(day:number, volunteer:number): Observable<void> {
        return this._http.put<void>("/api/Scheduling/UpdateChoiseVolunteer/"+day, volunteer);
    }
}

