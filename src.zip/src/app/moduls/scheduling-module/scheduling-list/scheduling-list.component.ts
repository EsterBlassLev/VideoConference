import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Scheduling } from 'src/app/models/Scheduling';
import { SchedulingService } from '../scheduling.service';

@Component({
  selector: 'app-scheduling-list',
  templateUrl: './scheduling-list.component.html',
  styleUrls: ['./scheduling-list.component.scss']
  //כנל כאן הייתי מוסיפה
  //  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SchedulingListComponent implements OnInit {

  constructor(private _schedulingService:SchedulingService, private _cdr: ChangeDetectorRef) {  }

  subscribtion:Subscription;
  scheduling: Scheduling; 
  
  ngOnInit(): void {
    this.subscribtion=this._schedulingService.getAllScheduling().subscribe(data=>{
      this.scheduling=data;
      this._cdr.detectChanges();
    })
  }

  ngOnDestroy(): void {
    this.subscribtion.unsubscribe();
  }

}
