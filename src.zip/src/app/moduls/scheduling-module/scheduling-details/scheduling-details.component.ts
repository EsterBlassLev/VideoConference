import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Scheduling } from 'src/app/models/Scheduling';
import { SchedulingService } from '../scheduling.service';

@Component({
  selector: 'app-scheduling-details',
  templateUrl: './scheduling-details.component.html',
  styleUrls: ['./scheduling-details.component.scss']
})
export class SchedulingDetailsComponent implements OnInit {

  constructor(private _ScheduleService: SchedulingService, private _acr: ActivatedRoute, private _cdr: ChangeDetectorRef, private _router: Router) { }

  subscriptionGet: Subscription;
  subscriptionPut: Subscription;

  ngOnInit(): void {
    this.subscriptionGet = this._ScheduleService.getAllScheduling().subscribe(data => {
      this.scheduling = data;
      this._cdr.detectChanges();
    })
  }
  private _scheduling: Scheduling;

  get scheduling(): Scheduling {
    return this._scheduling;
  }

  schedulingForm: FormGroup = new FormGroup({
    "day1": new FormControl(""),
    "day2": new FormControl(""),
    "day3": new FormControl(""),
    "day4": new FormControl(""),
    "day5": new FormControl(""),
    "day6": new FormControl(""),
  })

  set scheduling(val: Scheduling) {
    this._scheduling = val;
    if (val) {
      this.schedulingForm.controls["day1"].setValue(val[0].Choise?.id);
      this.schedulingForm.controls["day2"].setValue(val[1].Choise?.id);
      this.schedulingForm.controls["day3"].setValue(val[2].Choise?.id);
      this.schedulingForm.controls["day4"].setValue(val[3].Choise?.id);
      this.schedulingForm.controls["day5"].setValue(val[4].Choise?.id);
      this.schedulingForm.controls["day6"].setValue(val[5].Choise?.id);
    }
  }
  count =0;
  save() {
    this.count = 0;
    for (let i = 0; i < 6; i++) {
      if (this.schedulingForm.controls[`day${i + 1}`].value!='' && this.schedulingForm.controls[`day${i + 1}`].touched) {
        this.subscriptionPut = this._ScheduleService.UpdateSchedulingByDay((i + 1), +this.schedulingForm.controls[`day${i + 1}`].value).subscribe(data => {
          console.log("עדכון מתנדב ליום " + (i + 1) + " נשמר בהצלחה");
          this.count++;
        }, err => { console.log("update process failed"); }
        );
      }
      else {
        this.count++;
      }
    }
    if (this.count === 6)
      alert("העדכון נשמר בהצלחה!")
    this._router.navigate(["/scheduling"]);
  }

  ngOnDestroy(): void {
    this.subscriptionGet.unsubscribe();
    if (this.subscriptionPut != undefined)
      this.subscriptionPut.unsubscribe();
  }
}
