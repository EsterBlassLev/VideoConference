import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { Route, RouterModule } from "@angular/router";
import { SchedulingDetailsComponent } from "./scheduling-details/scheduling-details.component";
import { SchedulingListComponent } from "./scheduling-list/scheduling-list.component";
import { SchedulingService } from "./scheduling.service";

const APP_ROUTES: Route[] = [
    { path:"", pathMatch: "full", redirectTo: "volunteer" },
    { path: "scheduling", component: SchedulingListComponent },
    { path: "schedulingDetails", component: SchedulingDetailsComponent },
  ];
  
  @NgModule({
    declarations: [SchedulingDetailsComponent, SchedulingListComponent],
    imports: [CommonModule, HttpClientModule, RouterModule, ReactiveFormsModule, FormsModule  , RouterModule.forChild(APP_ROUTES)],
    providers: [SchedulingService],
    exports: [SchedulingListComponent]
  
  })
  export class SchedulingModule { }