import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Volunteer } from 'src/app/models/Volunteer';
import { VolunteerService } from '../VolunteerService';


@Component({
  selector: 'app-volunteer-list-component',
  templateUrl: './volunteer-list-component.component.html',
  styleUrls: ['./volunteer-list-component.component.scss']
  //אם היתה לי אפשרות הייתי עושה את זה כאן וכן הייתי כותבת את מה שכתבתי בהמשך שלא רלוומטטי כרגע
  //changeDetection: ChangeDetectionStrategy.Default
})

export class VolunteerListComponentComponent implements OnInit {

  constructor(private _volunteerService:VolunteerService, private _cdr: ChangeDetectorRef) {  }

  subscribtion:Subscription;
  volunteers: Volunteer[];

  ngOnInit(): void {
    this.subscribtion=this._volunteerService.getAllVolunteers().subscribe(data=>{
      this.volunteers=data;
      this._cdr.detectChanges();
    })
  }

  ngOnDestroy(): void {
    this.subscribtion.unsubscribe();
  }

}