import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { disableDebugTools } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { BehaviorSubject, Observable } from "rxjs";
import { Volunteer } from "src/app/models/Volunteer";

@Injectable()
export class VolunteerService {

    constructor(private _http: HttpClient) { }

    getAllVolunteers(): Observable<Volunteer[]> {
        return this._http.get<Volunteer[]>("api/Volunteer/GetVolunteers");
    }
    getVolunteerById(id:number): Observable<Volunteer> {
        return this._http.get<Volunteer>("/api/volunteer/GetVolunteerById/"+id)
    }

    updateVolunteer(id: number, volunteerToUpdate: Volunteer) {
        return this._http.put<Volunteer>("/api/Volunteer/UpdateVolunteer/" + id, volunteerToUpdate);
    }
}