import { Volunteer } from 'src/app/models/Volunteer';
import { VolunteerService } from "../VolunteerService";
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-volunteer-details',
  templateUrl: './volunteer-details.component.html',
  styleUrls: ['./volunteer-details.component.scss']
  //changeDetection:ChangeDetectionStrategy.OnPush
})

export class VolunteerDetailsComponent implements OnInit {

  constructor(private _VolunteerService: VolunteerService, private _acr: ActivatedRoute, private _cdr: ChangeDetectorRef, private _router: Router) { }

  volunteerId: number = 0;
  private _volunteer: Volunteer;

  subscriptionParams: Subscription;
  subscriptionGet: Subscription;
  subscriptionPut: Subscription;

  ngOnInit(): void {
    this.subscriptionParams = this._acr.paramMap.subscribe(param => {
      if (param.get("id") && param.get("id") != undefined) {
        this.volunteerId = +param.get("id");
        this.subscriptionGet = this._VolunteerService.getVolunteerById(this.volunteerId).subscribe(data => {
          this.volunteer = data;
        });
      }
    })
  }

  get volunteer(): Volunteer {
    return this._volunteer;
  }

  set volunteer(val: Volunteer) {
    this._volunteer = val;
    if (val) {
      this.volunteerForm.controls["id"].setValue(val.id);
      this.volunteerForm.controls["firstName"].setValue(val.firstName);
      this.volunteerForm.controls["lastName"].setValue(val.lastName);
      this.volunteerForm.controls["day1"].setValue(val.days[0]);
      this.volunteerForm.controls["day2"].setValue(val.days[1]);
      this.volunteerForm.controls["day3"].setValue(val.days[2]);
      this.volunteerForm.controls["day4"].setValue(val.days[3]);
      this.volunteerForm.controls["day5"].setValue(val.days[4]);
      this.volunteerForm.controls["day6"].setValue(val.days[5]);
    }
  }

  volunteerForm: FormGroup = new FormGroup({
    "id": new FormControl("", Validators.required),
    "firstName": new FormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(10)]),
    "lastName": new FormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(10)]),
    "day1": new FormControl(""),
    "day2": new FormControl(""),
    "day3": new FormControl(""),
    "day4": new FormControl(""),
    "day5": new FormControl(""),
    "day6": new FormControl(""),
  })

  days: boolean[] = [];
  volunteerToSend: Volunteer = new Volunteer();

  saveVolunteer() {
    for (let i = 0; i < this.volunteer.days.length; i++) {
      if (this.volunteer.days[i] && !this.volunteerForm.controls[`day${i + 1}`].value) {
        alert("הינך משובץ כבר ביום " + (i + 1) + " אינך יכול לבטל התנדבות ביום בו שובצת! ");
        return;
      }
      this.days.push(this.volunteerForm.controls[`day${i + 1}`].value);
    }
    this.volunteerToSend.id = this.volunteerForm.controls["id"].value;
    this.volunteerToSend.firstName = this.volunteerForm.controls["firstName"].value;
    this.volunteerToSend.lastName = this.volunteerForm.controls["lastName"].value;
    this.volunteerToSend.days = this.days;
    this._VolunteerService.updateVolunteer(this.volunteerId, this.volunteerToSend).subscribe(data =>
    console.log(), err => { console.log("update process failed"); }
    );
    alert("העדכון נשמר בהצלחה!")
    this._router.navigate(["/volunteer"]);
  }
  
  ngOnDestroy(): void {
    this.subscriptionParams.unsubscribe();
    this.subscriptionGet.unsubscribe();
    if (this.subscriptionPut != undefined)
      this.subscriptionPut.unsubscribe();
  }
}