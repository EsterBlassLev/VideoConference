import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VolunteerService } from './VolunteerService';
import { HttpClientModule } from '@angular/common/http';
import { Route, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VolunteerListComponentComponent } from './volunteer-list-component/volunteer-list-component.component';
import { VolunteerDetailsComponent } from './volunteer-details/volunteer-details.component';

const APP_ROUTES: Route[] = [
  { path:"", pathMatch: "full", redirectTo: "volunteer" },
  { path: "volunteer", component: VolunteerListComponentComponent },
  { path: "volunteer/:id", component: VolunteerDetailsComponent },
];

@NgModule({
  declarations: [VolunteerListComponentComponent, VolunteerDetailsComponent],
  imports: [CommonModule, HttpClientModule, RouterModule, ReactiveFormsModule, FormsModule  , RouterModule.forChild(APP_ROUTES)],
  providers: [VolunteerService],
  exports: [VolunteerListComponentComponent]

})
export class VolunteerModuleModule { }
